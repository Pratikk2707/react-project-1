import React, { useState } from 'react';
import { BrowserRouter as Router, Routes ,Route } from 'react-router-dom';
import './App.css';
import Login from './component/Login';
import UserManagement from './component/UserManagement';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" exact  element={<Login/>} />
        <Route path="/user-management"  element={<UserManagement/>} />
      </Routes>
    </Router>
  );
}

export default App;