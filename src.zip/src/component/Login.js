import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';
import backgroundImage from '../assets/background.jpg'; // Ensure the image path is correct

function Login() {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate  = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!userId || !password) {
      setError('Both fields are required.');
      return;
    }

    setError('');
    console.log('User ID:', userId);
    console.log('Password:', password);
    navigate('/user-management');
  };

  return (
    <div className="Login" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="login-container">
        <div className='login-form'>
            <div className='form-contents'>
                <h2>Hyundai Safety Analytics</h2>
                <h3>Sign-In</h3>
                <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="userId"><i className="fas fa-user"></i></label>
                    <input
                    type="text"
                    id="userId"
                    placeholder="USER ID"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password"><i className="fas fa-lock"></i></label>
                    <input
                    type="password"
                    id="password"
                    placeholder="PASSWORD"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    />
                </div>
                {error && <p className="error">{error}</p>}
                <button type="submit">Login</button>
                </form>
            </div>
        </div>
       
      </div>
    </div>
  );
}

export default Login;