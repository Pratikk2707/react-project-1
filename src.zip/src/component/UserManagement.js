import React from 'react';
import './UserManagement.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen, faPlus, faTrash } from "@fortawesome/free-solid-svg-icons"
import { faDownload } from '@fortawesome/free-solid-svg-icons/faDownload';

function UserManagement() {
  return (
    <div className="user-management">
      <aside className="sidebar">
        <h2>SAFETY ANALYTICS</h2>
        <nav>
          <ul>
            <li>Dashboard</li>
            <li>Data Exploration</li>
            <ul>
              <li>Make-Model-Model Year</li>
              <li>Dealer</li>
              <li>Claims</li>
            </ul>
            <li>Safety Analytics 360°</li>
            <li>Competitive Analysis</li>
            <li>Insights</li>
            <ul>
              <li>Safety Violation Predictions</li>
              <li>Recommendations</li>
            </ul>
            <li>Configuration</li>
            <ul>
              <li>Data Source</li>
              <li>Connections</li>
            </ul>
            <li>User Management</li>
            <li>Make</li>
            <li>Manual Data Upload</li>
            <li>Custom Fields</li>
          </ul>
        </nav>
      </aside>
      <main className="main-content">
        <header className="header">
          <h2>User Management</h2>
          <div className="actions">
            <button ><FontAwesomeIcon icon={faDownload} /></button>
            <button ><FontAwesomeIcon icon={faPlus} /></button>
          </div>
        </header>
        <div className='tableBlock'>
        <table className='sticky-thc'>
          <thead>
            <tr>
              <th></th>
              <th>User</th>
              <th>Email ID</th>
              <th>Role</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {Array(10).fill(0).map((_, idx) => (
              <tr key={idx}>
                <td><input type='checkbox'/></td>
                <td>Michael Scott</td>
                <td>michael.scott@gmail.com</td>
                <td>Admin</td>
                <td>Active</td>
                <td>
                  <div classname="btn-container">
                  <button className='btn'> <FontAwesomeIcon icon={faPen} /> </button>
                  <button className='btn'>  <FontAwesomeIcon icon={faTrash} /></button>
                  </div>
                  
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
        
      </main>
    </div>
  );
}

export default UserManagement;